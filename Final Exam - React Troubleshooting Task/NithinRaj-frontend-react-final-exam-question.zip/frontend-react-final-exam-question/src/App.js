import "./App.css";
import EthereumAddressList from "./ethereumAddressList";
function App() {
  return (
    <div className="App">
      <EthereumAddressList />
    </div>
  );
}

export default App;
